#!/usr/bin/env bash
set -x
cd /root/board-pool/board2/esp32
. /opt/esp/idf/export.sh >/dev/null 2>&1
idf.py -B build_kb -p "$FLASH_PORT" flash 2>&1 | tail -2
sleep 3
python3 - <<'PY'
import serial, time, os, sys
p = os.environ["SERIAL_PORT"]
s = serial.Serial(p, 115200, timeout=1)
s.dtr = True; s.rts = False; s.reset_input_buffer()
import subprocess
subprocess.run(["python3","-m","esptool","--chip","esp32s3","-p",os.environ["FLASH_PORT"],"run"],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
t0=time.time(); buf=open("/root/board-pool/batches/e52_b2.out","wb")
while time.time()-t0 < 220:
    d=s.read(4096)
    if d: buf.write(d); buf.flush()
buf.close(); s.close()
print("E49_HARVEST_DONE")
PY
