#!/bin/bash
python3 - <<'PY'
import sys, time
sys.path.insert(0,'/workspace/esp32-needle-3/tools')
import serial_api
t0=time.time(); buf=open('/root/board-pool/batches/e51_b1h.out','wb')
dev=serial_api.Device('/dev/ttyACM0',baud=115200,echo=True,boot_wait=0)
try:
    while time.time()<t0+58:
        ln=dev._line()
        if ln: buf.write((ln if isinstance(ln,str) else ln.decode('utf8','replace')).encode()+b'\n'); buf.flush()
except Exception as ex: buf.write(f'EXC {ex}\n'.encode())
finally: buf.close()
try: dev.serial.close()
except Exception: pass
print('HARV_DONE')
PY
