#!/usr/bin/env python3
"""B1 transfer test: put ONLY the W3 prefix wrapper + W3 call switch onto the B1 lineage.
Apply at turnover (board1 must not be live). Aborts on any failed check; never reuses offsets."""
import re, sys
p='engine/src/nd_model.c'; s=open(p).read()
donor=open('/tmp/B2p1fix_nd_model_preserved.c').read()
def extract(txt, name):
    i=txt.index("static void %s(" % name); j=txt.index("\n}\n", i)+3; return i,j,txt[i:j]
# donor wrapper with the guarded prefix variant (take it from the live B2 source if patched, else build it)
try:
    b2=open('/root/board-pool/board2/engine/src/nd_model.c').read()
    _,_,variant = extract(b2, "kron_apply_pre768")
    wrapper = variant
except Exception:
    print("ABORT: donor prefix wrapper not found on board2"); sys.exit(1)
assert "na != 32u" in wrapper and ", 6);" in wrapper and ", 24);" in wrapper, "donor wrapper malformed"
# 1) insert the wrapper after this tree's own kron_apply definition
i,j,own = extract(s, "kron_apply")
s = s[:j] + "\n" + wrapper + s[j:]
# 2) the W3 call as LITERAL two-line text, located AFTER the insertion, W3-only (fp[23]/fp[24])
lit = re.search(r"kron_apply\(m, m->hada_a, m->hada_b, fp\[23\], fp\[24\],\s*\n\s*L->w3a\.shape\[0\], L->w3b\.shape\[0\]\);", s)
assert lit, "ABORT: W3 two-line call not found"
assert s.count(lit.group(0))==1, "ABORT: W3 call not unique"
s = s[:lit.start()] + lit.group(0).replace("kron_apply(", "kron_apply_pre768(", 1) + s[lit.end():]
open(p,'w').write(s)
t=open(p).read()
checks={"wrapper": t.count("void kron_apply_pre768(")==1,
        "W3 switched": bool(re.search(r"kron_apply_pre768\(m, m->hada_a, m->hada_b, fp\[23\]", t)),
        "W1 ordinary": bool(re.search(r"kron_apply\(m, m->hada_a, m->hada_b, fp\[19\]", t)),
        "W2 ordinary": bool(re.search(r"kron_apply\(m, m->hada_a, m->hada_b, fp\[21\]", t)),
        "guard": "na != 32u || nb != 32u || m->d_model != 768u" in t,
        "scheduling": ", 6);" in t and ", 24);" in t}
print("B1-W3PRE CHECKS:", checks)
sys.exit(0 if all(checks.values()) else 1)
