#!/usr/bin/env python3
"""B2 W3 residual emit, clone-based, with the mentor's corrections baked in:
two-line literal W3 match AFTER the clone is inserted, correct fallback signature, extraction
by function boundaries, q<dm guards in all eight stores and the tail, caller d4 loop removed."""
import re, sys
p='engine/src/nd_model.c'; s=open(p).read()
i=s.index("static ND_HOT void kron2_rows(void *vc")
j=s.index("\n}\n", s.index("for (; l < c->nb; l++)", i))+3
body=s[i:j]
clone=body.replace("void kron2_rows(", "void kron2_rows_res(", 1)
assert "} else {" not in clone or True
# fused stores + tail, each guarded by q < dm
clone=re.sub(r"c->dst\[\(size_t\)k \* c->nb \+ l \+ (\d)\] = s\1;",
             lambda m: "if ((size_t)k * c->nb + l + %s < c->dm) c->u[(size_t)k * c->nb + l + %s] += s%s * c->d4[(size_t)k * c->nb + l + %s];" % (m.group(1),m.group(1),m.group(1),m.group(1)), clone)
clone=re.sub(r"c->dst\[\(size_t\)k \* c->nb \+ l\] = sum;",
             "if ((size_t)k * c->nb + l < c->dm) c->u[(size_t)k * c->nb + l] += sum * c->d4[(size_t)k * c->nb + l];", clone)
rctx="typedef struct { nd_model *m; float *u; const float *d4; const float *b; uint32_t na, nb, dm; } kron2r_ctx;"
clone=clone.replace("const kron2_ctx *c = (const kron2_ctx *)vc;","const kron2r_ctx *c = (const kron2r_ctx *)vc;",1)
s=s[:j]+"\n"+rctx+"\n"+clone+s[j:]
open(p,'w').write(s)
t=open(p).read()
checks={"clone":t.count("void kron2_rows_res(")==1,"guarded stores":t.count("< c->dm) c->u[")==9}
print("B2-RESID CHECKS:", checks, "(wrapper/caller wiring intentionally left for the next step)")
sys.exit(0 if checks["clone"] else 1)
