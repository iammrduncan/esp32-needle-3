/* Waveshare ESP32-S3-DEV-KIT: WS2812B on GPIO38.
 * One latched frame; no periodic work competes with inference. */
#include <stdio.h>
#include "esp_err.h"
#include "driver/rmt_tx.h"
#include "driver/rmt_encoder.h"
#include "board_led.h"

void board_led_set(int on)
{
    rmt_channel_handle_t channel = NULL;
    rmt_encoder_handle_t encoder = NULL;
    rmt_tx_channel_config_t cfg = {
        .gpio_num = 38, .clk_src = RMT_CLK_SRC_DEFAULT,
        .resolution_hz = 10000000, .mem_block_symbols = 64,
        .trans_queue_depth = 1,
    };
    rmt_copy_encoder_config_t enc_cfg = {0};
    rmt_transmit_config_t tx = { .loop_count = 0 };
    rmt_symbol_word_t frame[25] = {0};
    /* Equal GRB channels give white; 32/255 is ample for identification. */
    unsigned value = on ? 32 : 0;
    for (int bit = 0; bit < 24; ++bit) {
        int one = (value >> (7 - bit % 8)) & 1;
        frame[bit] = (rmt_symbol_word_t) {
            .level0 = 1, .duration0 = one ? 9 : 3,
            .level1 = 0, .duration1 = one ? 3 : 9,
        };
    }
    frame[24] = (rmt_symbol_word_t) {
        .level0 = 0, .duration0 = 1500,
        .level1 = 0, .duration1 = 1500,
    };
    ESP_ERROR_CHECK(rmt_new_tx_channel(&cfg, &channel));
    ESP_ERROR_CHECK(rmt_new_copy_encoder(&enc_cfg, &encoder));
    ESP_ERROR_CHECK(rmt_enable(channel));
    ESP_ERROR_CHECK(rmt_transmit(channel, encoder, frame, sizeof(frame), &tx));
    ESP_ERROR_CHECK(rmt_tx_wait_all_done(channel, 1000));
    ESP_ERROR_CHECK(rmt_disable(channel));
    ESP_ERROR_CHECK(rmt_del_encoder(encoder));
    ESP_ERROR_CHECK(rmt_del_channel(channel));
    printf("EVT led=%s gpio=38 rgb=%u,%u,%u\n", on ? "white" : "off", value, value, value);
    fflush(stdout);
}
