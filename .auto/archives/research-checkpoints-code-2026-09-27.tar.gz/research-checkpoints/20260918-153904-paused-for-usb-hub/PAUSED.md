# Autoresearch paused for USB hub and additional ESP32 boards

Paused at 2026-09-18T15:39:04.754568-05:00 on explicit user request. `/autoresearch off` persisted inactive and aborted the UART benchmark reader. No flash writer was active at interruption. No remaining experiment processes or accessible serial descriptors were found. Host needle3-api.service is inactive. Pi/container remain running idle.

Branch: autoresearch/decode-tps-2026-09-18
HEAD: fe806949b074d635bc8985afb33856451d1e8b32 ideas: record the 4-bit hoist null, the packed-load dead end, the Sinkhorn veto

The working tree has an unfinished candidate in engine/src/nd_model.c, preserved here with a full patch and source copy. Research records are copied in auto/, and Pi conversation in pi-session.jsonl. Do not treat the unfinished candidate as a completed measured experiment.

The interrupted command had already flashed OPT.bin for its third (repeat) benchmark and was waiting on UART when aborted. Last running firmware was therefore the run #11 OPT build. OPT.bin and candidate NORMS2.bin are both preserved here. The first two short bench results were 2.703 tok/s (OPT) and 2.702 tok/s (NORMS2); the repeat was interrupted. Last fully recorded research best was 2.6767 tok/s.

Existing board USB identities: flash Espressif 90:E5:B1:D1:C0:F8; console 1a86 5B91041931. Existing udev rules match only these identities. Before resuming with three boards, identify each flash/console pair and configure distinct stable paths and separate build/output ownership for parallel experiments. Do not auto-resume until the user is ready.
